package com.company;
import java.util.Scanner;
class RandomId{
    Scanner cid=new Scanner(System.in);
    public int cid1;
    public int cid2;
    public int cid3;
    public RandomId(){
        System.out.println("Enter 3 customer ID: ");

        cid1=cid.nextInt();
        cid2=cid.nextInt();
        cid3=cid.nextInt();
    }
    public int getCid1(){
        return cid1;
    }
    public int getCid2(){
        return cid2;
    }
    public int getCid3(){
        return cid3;
    }
}