
package com.company;
import java.util.Scanner;

public class CarCompany{

    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        // write your code here
        int user_input;
        System.out.println("........WELCOME....... ");
        System.out.println("Car Purchase Utility Company");
        System.out.println("Press key between them");
        System.out.println("Admin LogIn ........press 1");
        System.out.println("Customer LogIn........press 2");
        System.out.println("Check out latest cars........press 3");
        System.out.println("Exit........press 4");
        user_input=in.nextInt();
        int key=user_input;
        switch(key){
            case 1:
            {
                Scanner admin = new Scanner(System.in);
                System.out.println("Enter your Admin ID and their password");
                String admin_id = admin.nextLine();
                String admin_password = admin.nextLine();

                if(admin_id.equals("admin")&&admin_password.equals("admin"))

                {
                    System.out.println("Choose any no. between them");
                    System.out.println("1.Add new customer");
                    System.out.println("2.Add new car to exiting customer");
                    System.out.println("3.list of all customers with their cars");
                    System.out.println("4.to check list of all customer with their individuals ID ");
                    System.out.println("5.Generate prizes for the customer");
                    int admin_input = admin.nextInt();
                    switch (admin_input) {
                        case 1: {
                            Scanner new_customer = new Scanner(System.in);
                       /* ArrayList<String> add_customer=new ArrayList<String>();
                        ArrayList<Integer> add_id=new ArrayList<Integer>();
                        System.out.println("Enter the customer name: ");
                        while(new_customer.hasNextLine()){
                            add_customer.add(new_customer.nextLine());
                            break;
                        }
                        System.out.print(add_customer);*/

                            String customer_name = new_customer.nextLine();
                            System.out.println("Enter the customer ID: ");
                            int customer_id = new_customer.nextInt();
                            System.out.println("customer name=" + customer_name);
                            System.out.println("customer name=" + customer_id);
                            break;

                        }
                        case 2: {

                        }
                    }


                }
                else

                {
                    System.out.println("this id and password is incorrect");
                }

                break;
            }
            case 2:

                break;
            case 3:

                break;
            case 4:

                break;
            default:
                System.out.println("Please press a Valid key");
                break;
        }




    }
}





